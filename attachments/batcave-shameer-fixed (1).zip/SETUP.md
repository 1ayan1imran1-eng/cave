# THE BATCAVE — setup & storage

## Fixed access

- Operator: **Shameer**
- Cave identifier: **84fd6e98**
- Cave password: **sheeza**
- There is one local operator only. There is no sign-up or multiple-account flow.

The identifier is a locator/access key, not a Google search password. A website cannot make Google search for a site merely because someone types `84fd6e98`. Once the site URL is known, the identifier + password gate protects the app UI.

## How the system/storage page works

The cave saves immediately to browser `localStorage`, so projects, roadmaps, notes, and settings survive normal reloads on the same browser/device.

For cross-device backup:

1. Create a free Supabase project.
2. Open **SQL Editor**.
3. Paste the SQL shown in **System → Remote storage** and run it once.
4. In the cave, enter the Supabase **Project URL** and **anon/public key**.
5. Press **Push** once.
6. From another device, open the cave, enter the same cave identifier and password, then use **Pull** if the remote copy is not loaded automatically.

### Important security detail

The cave data is now encrypted in the browser with the cave password using PBKDF2 + AES-GCM before it is uploaded. The Supabase anon key is public by design; **never paste a service-role key into the site**.

The current Supabase policy allows the single row to be read/written by the public anon client, but the stored payload is encrypted. This protects the contents from someone who can read the row without the password. It does not provide server-side ownership or protection against someone deleting/replacing the row. Keep the JSON export backup too.

### "Forever" storage

No browser or free cloud service can honestly guarantee data forever. The practical setup is:

- localStorage for instant local persistence;
- encrypted Supabase for remote backup;
- JSON export as an independent backup.

Export a JSON backup occasionally, especially before changing the access password.

## GitHub Pages

The current workspace uses TanStack Start/Nitro and is ready for a server-capable deployment such as Vercel. GitHub Pages is a **static-only** host and cannot run the current SSR/server output by itself.

You can still keep the complete source in GitHub. If you specifically want the app itself hosted on GitHub Pages, the project needs a separate static SPA build configuration (and GitHub Pages SPA fallback/base-path handling). Do not upload the `.vercel/output/functions` server bundle expecting GitHub Pages to execute it.
