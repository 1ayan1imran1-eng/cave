create table if not exists cave_state (
  id text primary key,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table cave_state enable row level security;

drop policy if exists "cave_anon_rw" on cave_state;
create policy "cave_anon_rw" on cave_state
  for all
  using (true)
  with check (true);
