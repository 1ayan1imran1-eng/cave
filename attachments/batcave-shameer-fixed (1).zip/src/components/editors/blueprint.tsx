import { useRef, useState, type PointerEvent } from "react";
import type { BlueprintData, BlueprintStroke } from "@/lib/types";
import { BatButton } from "../bat-button";
import { nid } from "@/lib/utils";

const COLORS: { id: BlueprintStroke["color"]; hex: string }[] = [
  { id: "red", hex: "#b42323" },
  { id: "bone", hex: "#eceae4" },
  { id: "steel", hex: "#9a968e" },
];

export function BlueprintEditor({
  data,
  onChange,
}: {
  data: BlueprintData;
  onChange: (next: BlueprintData) => void;
}) {
  const svg = useRef<SVGSVGElement>(null);
  const current = useRef<BlueprintStroke | null>(null);
  const [color, setColor] = useState<BlueprintStroke["color"]>("red");
  const [width, setWidth] = useState(2.4);

  function pos(e: PointerEvent<SVGSVGElement>) {
    const box = svg.current!.getBoundingClientRect();
    return {
      x: ((e.clientX - box.left) / box.width) * 1000,
      y: ((e.clientY - box.top) / box.height) * 620,
    };
  }

  function down(e: PointerEvent<SVGSVGElement>) {
    const stroke: BlueprintStroke = {
      id: nid(),
      points: [pos(e)],
      color,
      width,
    };
    current.current = stroke;
    onChange({ kind: "blueprint", strokes: [...data.strokes, stroke] });
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function move(e: PointerEvent<SVGSVGElement>) {
    if (!current.current) return;
    const id = current.current.id;
    const pt = pos(e);
    current.current.points.push(pt);
    onChange({
      kind: "blueprint",
      strokes: data.strokes.map((s) =>
        s.id === id ? { ...s, points: [...s.points, pt] } : s,
      ),
    });
  }

  function up() {
    current.current = null;
  }

  function d(points: { x: number; y: number }[]) {
    if (!points.length) return "";
    return points
      .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
      .join(" ");
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        {COLORS.map((c) => (
          <BatButton
            key={c.id}
            label={c.id}
            variant="inline"
            active={color === c.id}
            onClick={() => setColor(c.id)}
          />
        ))}
        <label className="ml-2 flex items-center gap-2 text-[0.65rem] tracking-[0.18em] text-muted uppercase">
          Weight
          <input
            type="range"
            min={1}
            max={8}
            step={0.4}
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
          />
        </label>
        <BatButton
          label="Undo"
          variant="inline"
          onClick={() => onChange({ kind: "blueprint", strokes: data.strokes.slice(0, -1) })}
        />
        <BatButton
          label="Clear"
          variant="inline"
          onClick={() => onChange({ kind: "blueprint", strokes: [] })}
        />
      </div>
      <svg
        ref={svg}
        viewBox="0 0 1000 620"
        className="h-[min(62vh,560px)] w-full touch-none rounded-[10px] border border-line bg-inset"
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
      >
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#2c2c32"
              strokeWidth="1"
            />
          </pattern>
        </defs>
        <rect width="1000" height="620" fill="url(#grid)" />
        {data.strokes.map((s) => (
          <path
            key={s.id}
            d={d(s.points)}
            fill="none"
            stroke={COLORS.find((c) => c.id === s.color)?.hex}
            strokeWidth={s.width}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ))}
      </svg>
    </div>
  );
}
