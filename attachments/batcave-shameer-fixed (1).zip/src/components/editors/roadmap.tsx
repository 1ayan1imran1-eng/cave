import { useRef, useState, type PointerEvent } from "react";
import type { NodeStatus, RoadmapData, RoadmapNode } from "@/lib/types";
import { BatButton } from "../bat-button";
import { nid } from "@/lib/utils";

const STATUS: NodeStatus[] = ["pending", "active", "done"];
const BOARD_W = 1500;
const BOARD_H = 720;
const START = { x: 48, y: BOARD_H / 2 - 42 };
const END = { x: BOARD_W - 190, y: BOARD_H / 2 - 42 };

export function RoadmapEditor({ data, onChange }: { data: RoadmapData; onChange: (next: RoadmapData) => void }) {
  const board = useRef<HTMLDivElement>(null);
  const [connectFrom, setConnectFrom] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(data.nodes[0]?.id ?? null);
  const drag = useRef<{ id: string; ox: number; oy: number; nx: number; ny: number } | null>(null);
  const pan = useRef<{ x: number; y: number; sl: number; st: number } | null>(null);
  const selectedNode = data.nodes.find((n) => n.id === selected) ?? null;

  function addNode() {
    const lane = data.nodes.length % 3;
    const col = Math.floor(data.nodes.length / 3);
    const node: RoadmapNode = {
      id: nid(),
      x: 300 + col * 230,
      y: 120 + lane * 180,
      title: `Step ${data.nodes.length + 1}`,
      detail: "",
      status: "pending",
    };
    onChange({ ...data, nodes: [...data.nodes, node] });
    setSelected(node.id);
  }

  function patchNode(id: string, patch: Partial<RoadmapNode>) {
    onChange({ ...data, nodes: data.nodes.map((n) => (n.id === id ? { ...n, ...patch } : n)) });
  }

  function onNodeDown(e: PointerEvent<HTMLButtonElement>, node: RoadmapNode) {
    e.stopPropagation();
    setSelected(node.id);
    drag.current = { id: node.id, ox: e.clientX, oy: e.clientY, nx: node.x, ny: node.y };
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function onBoardMove(e: PointerEvent<HTMLDivElement>) {
    if (drag.current) {
      const dx = e.clientX - drag.current.ox;
      const dy = e.clientY - drag.current.oy;
      patchNode(drag.current.id, { x: Math.max(230, Math.min(BOARD_W - 390, drag.current.nx + dx)), y: Math.max(40, Math.min(BOARD_H - 110, drag.current.ny + dy)) });
      return;
    }
    if (pan.current && board.current) {
      board.current.scrollLeft = pan.current.sl - (e.clientX - pan.current.x);
      board.current.scrollTop = pan.current.st - (e.clientY - pan.current.y);
    }
  }

  function onBoardDown(e: PointerEvent<HTMLDivElement>) {
    if (e.target !== e.currentTarget && (e.target as HTMLElement).tagName !== "svg") return;
    pan.current = { x: e.clientX, y: e.clientY, sl: e.currentTarget.scrollLeft, st: e.currentTarget.scrollTop };
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function endPointer() { drag.current = null; pan.current = null; }

  function toggleConnect(id: string) {
    if (!connectFrom) { setConnectFrom(id); return; }
    if (connectFrom === id) { setConnectFrom(null); return; }
    const exists = data.edges.some((ed) => (ed.from === connectFrom && ed.to === id) || (ed.from === id && ed.to === connectFrom));
    if (!exists) onChange({ ...data, edges: [...data.edges, { id: nid(), from: connectFrom, to: id }] });
    setConnectFrom(null);
  }

  const nodeCenter = (n: RoadmapNode) => ({ x: n.x + 84, y: n.y + 36 });

  return (
    <div className="space-y-4">
      <div className="panel p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="label-kicker">Mission route</p>
            <h2 className="mt-1 text-xl">Start → steps → end</h2>
            <p className="mt-1 text-sm text-muted">The START and END anchors stay fixed. Add steps between them, drag them around, then connect the route.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <BatButton label="Add step" variant="inline" onClick={addNode} />
            <BatButton label={connectFrom ? "Connecting…" : "Connect steps"} variant="inline" active={!!connectFrom} onClick={() => setConnectFrom(connectFrom ? null : selected)} disabled={!selected} />
          </div>
        </div>
      </div>

      <div className="rounded-[10px] border border-line bg-inset">
        <div ref={board} className="h-[min(72vh,680px)] overflow-auto" onPointerDown={onBoardDown} onPointerMove={onBoardMove} onPointerUp={endPointer} onPointerCancel={endPointer}>
          <div className="relative" style={{ width: BOARD_W, height: BOARD_H }}>
            <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "linear-gradient(#2c2c32 1px, transparent 1px), linear-gradient(90deg, #2c2c32 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
            <svg className="pointer-events-none absolute inset-0 h-full w-full">
              <defs><marker id="roadmap-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#b42323" /></marker></defs>
              <path d={`M ${START.x + 150} ${START.y + 42} C 250 ${START.y + 42}, 220 ${BOARD_H / 2}, ${data.nodes[0] ? data.nodes[0].x : END.x} ${data.nodes[0] ? data.nodes[0].y + 36 : END.y + 42}`} fill="none" stroke="#b42323" strokeWidth="2" strokeDasharray={data.nodes.length ? undefined : "8 8"} markerEnd="url(#roadmap-arrow)" opacity="0.75" />
              {data.edges.map((edge) => {
                const a = data.nodes.find((n) => n.id === edge.from); const b = data.nodes.find((n) => n.id === edge.to); if (!a || !b) return null;
                const p = nodeCenter(a); const q = nodeCenter(b); const mx = (p.x + q.x) / 2;
                return <path key={edge.id} d={`M ${p.x} ${p.y} C ${mx} ${p.y}, ${mx} ${q.y}, ${q.x} ${q.y}`} fill="none" stroke="#b42323" strokeWidth="2.5" markerEnd="url(#roadmap-arrow)" opacity="0.9" />;
              })}
              {data.nodes.length ? <path d={`M ${nodeCenter(data.nodes[data.nodes.length - 1]).x} ${nodeCenter(data.nodes[data.nodes.length - 1]).y} C ${END.x - 180} ${nodeCenter(data.nodes[data.nodes.length - 1]).y}, ${END.x - 120} ${END.y + 42}, ${END.x} ${END.y + 42}`} fill="none" stroke="#b42323" strokeWidth="2.5" markerEnd="url(#roadmap-arrow)" opacity="0.9" /> : null}
            </svg>

            <div className="absolute rounded-sm border border-accent bg-[#160b0b] px-5 py-4 shadow-[0_0_24px_rgb(180_35_35_/_.18)]" style={{ left: START.x, top: START.y, width: 150 }}>
              <p className="label-kicker text-accent-hot">Start</p><p className="mt-1 text-sm font-semibold">MISSION BEGINS</p>
            </div>
            <div className="absolute rounded-sm border border-bone/40 bg-[#101014] px-5 py-4" style={{ left: END.x, top: END.y, width: 150 }}>
              <p className="label-kicker text-bone">End</p><p className="mt-1 text-sm font-semibold">MISSION COMPLETE</p>
            </div>

            {data.nodes.map((node) => (
              <button key={node.id} type="button" onPointerDown={(e) => onNodeDown(e, node)} onClick={() => { setSelected(node.id); if (connectFrom) toggleConnect(node.id); }} className="absolute w-[168px] rounded-sm border px-3 py-2 text-left transition-shadow" style={{ left: node.x, top: node.y, borderColor: selected === node.id ? "#e03a3a" : connectFrom === node.id ? "#eceae4" : "#2c2c32", background: "#111114", boxShadow: selected === node.id ? "0 0 22px rgb(224 58 58 / .16)" : undefined }}>
                <p className="label-kicker mb-1">{node.status}</p><p className="truncate text-sm font-medium text-fg">{node.title}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
        <div className="panel p-4"><p className="label-kicker">How it works</p><div className="mt-3 grid gap-2 sm:grid-cols-3"><div className="bg-inset p-3"><b className="text-sm">01 · Add</b><p className="mt-1 text-xs text-muted">Create a step. It lands in the open middle of the canvas.</p></div><div className="bg-inset p-3"><b className="text-sm">02 · Connect</b><p className="mt-1 text-xs text-muted">Select Connect, then tap two steps to draw the route.</p></div><div className="bg-inset p-3"><b className="text-sm">03 · Track</b><p className="mt-1 text-xs text-muted">Mark each step pending, active, or done.</p></div></div></div>
        <aside className="panel h-fit p-4">
          {selectedNode ? <div className="flex flex-col gap-3"><p className="label-kicker">Selected step</p><input value={selectedNode.title} onChange={(e) => patchNode(selectedNode.id, { title: e.target.value })} className="w-full bg-inset px-2 py-2 text-sm text-fg outline-none ring-1 ring-line focus:ring-accent" /><textarea value={selectedNode.detail} onChange={(e) => patchNode(selectedNode.id, { detail: e.target.value })} rows={5} className="w-full bg-inset px-2 py-2 text-sm text-fg outline-none ring-1 ring-line focus:ring-accent" placeholder="What this step actually is." /><div className="flex flex-wrap gap-2">{STATUS.map((st) => <BatButton key={st} label={st} variant="inline" active={selectedNode.status === st} onClick={() => patchNode(selectedNode.id, { status: st })} />)}</div><BatButton label="Delete step" variant="inline" onClick={() => { onChange({ kind: "roadmap", nodes: data.nodes.filter((n) => n.id !== selectedNode.id), edges: data.edges.filter((e) => e.from !== selectedNode.id && e.to !== selectedNode.id) }); setSelected(null); }} /></div> : <p className="text-sm text-muted">Add or select a step to edit it.</p>}
        </aside>
      </div>
    </div>
  );
}
