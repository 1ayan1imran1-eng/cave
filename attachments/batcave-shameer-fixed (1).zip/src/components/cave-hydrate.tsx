import { useEffect, type ReactNode } from "react";
import { useCaveStore } from "@/lib/cave-store";

export function CaveHydrate({ children }: { children: ReactNode }) {
  useEffect(() => {
    void useCaveStore.persist.rehydrate();
    const t = window.setTimeout(() => {
      if (!useCaveStore.getState().hydrated) {
        useCaveStore.getState().setHydrated();
      }
    }, 600);
    return () => window.clearTimeout(t);
  }, []);
  return children;
}
