import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { BatEmblem } from "./bat-emblem";
import type { Project } from "@/lib/types";
import { TYPE_META } from "@/lib/types";
import { cn, formatStamp } from "@/lib/utils";

/**
 * Project vault.
 *
 * This intentionally uses a normal 2D card layout instead of the old 3D ring.
 * Each card is a real TanStack Router link, so navigation does not
 * depend on pointer events bubbling through a draggable/3D parent.
 */
export function VaultRing({ projects }: { projects: Project[] }) {
  const [query, setQuery] = useState("");
  const [type, setType] = useState<"all" | Project["type"]>("all");

  const visible = projects.filter((project) => {
    const matchesQuery = `${project.name} ${project.tagline ?? ""}`
      .toLowerCase()
      .includes(query.trim().toLowerCase());
    const matchesType = type === "all" || project.type === type;
    return matchesQuery && matchesType;
  });

  const types = Array.from(new Set(projects.map((project) => project.type)));

  return (
    <section className="flex flex-col gap-5">
      <div className="panel flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="label-kicker">Project files</p>
          <p className="mt-1 text-sm text-muted">
            Open a file to edit its dossier, roadmap, mission, evidence and blueprint.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search projects..."
            aria-label="Search projects"
            className="h-10 min-w-56 rounded-sm border border-line bg-inset px-3 text-sm text-fg outline-none placeholder:text-muted focus:border-accent"
          />
          <select
            value={type}
            onChange={(event) => setType(event.target.value as typeof type)}
            aria-label="Filter projects by type"
            className="h-10 rounded-sm border border-line bg-inset px-3 text-sm text-fg outline-none focus:border-accent"
          >
            <option value="all">All types</option>
            {types.map((projectType) => (
              <option key={projectType} value={projectType}>
                {TYPE_META[projectType].label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {projects.length === 0 ? (
        <div className="panel mx-auto flex min-h-[280px] w-full flex-col items-center justify-center gap-4 p-8 text-center">
          <BatEmblem className="h-8 w-20 fill-muted" />
          <div>
            <p className="text-fg">The vault is empty.</p>
            <p className="mt-1 text-sm text-muted">Create your first project to start building.</p>
          </div>
        </div>
      ) : visible.length === 0 ? (
        <div className="panel flex min-h-[220px] items-center justify-center p-8 text-center text-sm text-muted">
          No project files match that search.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      )}
    </section>
  );
}

export function ProjectCard({
  project,
  className,
}: {
  project: Project;
  className?: string;
}) {
  return (
    <Link
      to="/vault/$id"
      params={{ id: project.id }}
      aria-label={`Open ${project.name}`}
      className={cn(
        "group panel flex min-h-64 flex-col overflow-hidden text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-accent hover:shadow-[var(--shadow-cave)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent",
        className,
      )}
    >
      <div className="flex items-start justify-between border-b border-line p-4">
        <div>
          <p className="label-kicker text-accent">{TYPE_META[project.type].label}</p>
          <h3 className="mt-2 text-xl text-fg">{project.name}</h3>
        </div>
        <BatEmblem className="mt-1 h-4 w-8 fill-muted transition-colors group-hover:fill-accent" />
      </div>

      <div className="flex flex-1 flex-col p-4">
        <p className="line-clamp-3 text-sm leading-6 text-muted">
          {project.tagline || "No briefing added yet."}
        </p>

        <div className="mt-auto flex items-end justify-between gap-4 pt-6">
          <div>
            <p className="label-kicker">Last updated</p>
            <p className="mt-1 text-xs tabular text-muted">{formatStamp(project.updatedAt)}</p>
          </div>

          <span className="inline-flex items-center gap-2 rounded-sm border border-line bg-raised px-3 py-2 text-xs font-semibold tracking-[0.18em] text-fg uppercase transition-[background-color,border-color,color] duration-150 group-hover:border-accent group-hover:text-bone">
            <span aria-hidden="true">⌁</span>
            Open
          </span>
        </div>
      </div>
    </Link>
  );
}
