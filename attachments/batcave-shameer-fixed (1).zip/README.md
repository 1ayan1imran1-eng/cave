# THE BATCAVE — Shameer Edition

A private single-operator Batcave dashboard with a project vault, roadmaps, birthday protocol, intel, training, watch log, remote backup, and a 3D cave command center.

## Access

- Operator: `Shameer`
- Cave identifier: `84fd6e98`
- Cave password: `sheeza`

## Main fixes in this version

- Project vault now has a reliable visible file grid plus search/type filtering.
- New projects immediately open and remain persisted in browser storage.
- Roadmap projects use a large canvas with fixed START and END anchors and editable steps between them.
- Main command-center cave has a deeper 3D diorama, Batmobile, computer banks, cave backdrop, pillars, and signal beam.
- Supabase remote payloads are encrypted client-side with the cave password before upload.
- One operator only; no account registration or multi-user UI.
- System page explains Supabase setup and local/remote backups.

See `SETUP.md` for storage and deployment notes.
